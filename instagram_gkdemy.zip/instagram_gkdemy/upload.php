<html>
    <head>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.0/trix.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <!-- <script src="http://127.0.0.1:8000/js/jquery..jsss"></script> -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.0/trix.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    </head>
    <body>
        <form action="instagram.php" method="POST" enctype="multipart/form-data">
            <div class="card card-default">
                <div class="card-header h3">Create Post</div>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="post_title">Name</label>
                            <input type="text" id="post_title" value="" class="form-control" placeholder="Name field must be unique" name="post_title">
                        </div>

                        <div class="form-group">
                            <label for="post_categories">Categories</label>
                            <input type="text" id="post_categories" value="" class="form-control" placeholder="" name="post_categories">
                        </div>

                        <div class="form-group">
                            <label for="post_copright">Copyright</label>
                            <input type="text" id="post_copright" value="" class="form-control" placeholder="" name="post_copright">
                        </div>

                        <div class="form-group">
                            <label for="post_desc">Description</label>
                            <input id="post_desc" type="hidden" name="post_desc">
                            <trix-editor input="post_desc"></trix-editor>
                        </div>

                        <div class="form-group">
                            <label for="post_datetime">Datetime</label>
                            <input type="text" id="post_datetime" autocomplete="false" value="" class="form-control datepicker" placeholder="" name="post_datetime">
                        </div>

                        <div class="form-group">
                            <label for="featured_image">Feature Image</label>
                            <input type="file" id="featured_image" class="form-control" name="featured_image">
                        </div>
                        

                        <div class="form-group">
                            <button type="submit" class="btn btn-success" name="createPost">Add Post</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <style>
            th,td {
                padding: 10px;
            }
        </style>
        <script>
            $(document).ready(function() {
                $('.datepicker').datepicker({
                    format: 'd MM yyyy',
                    autoclose: true
                });
            })
        </script>
       </body>
</html>