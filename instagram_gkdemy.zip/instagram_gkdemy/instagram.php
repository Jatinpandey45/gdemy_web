<?php
// if (isset($_POST['createPost'])) {
//     print_r($_POST);
//     $uploads_dir = '/uploads';
//     $tmp_name = $_FILES["featured_image"]["tmp_name"];
//     // basename() may prevent filesystem traversal attacks;
//     // further validation/sanitation of the filename may be appropriate
//     $name = $_FILES["featured_image"]["name"];
//     print_r($tmp_name);
//     print_r($_FILES["featured_image"]["name"]);
//     print_r('$_FILES["featured_image"]["name"]');
//     move_uploaded_file($tmp_name, "$uploads_dir/$name");
//     echo "\n";
// }

    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["featured_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    // Check if image file is a actual image or fake image
    if(isset($_POST["createPost"])) {
        $check = getimagesize($_FILES["featured_image"]["tmp_name"]);
        if($check !== false) {
            // echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            // echo "File is not an image.";
            $uploadOk = 0;
        }
    }
    // Check if file already exists
    if (file_exists($target_file)) {
        // echo "Sorry, file already exists.";
        $uploadOk = 0;
    }
    // Check file size
    if ($_FILES["featured_image"]["size"] > 500000) {
        // echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        // echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        // echo "Sorry, your file was not uploaded.";
    // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["featured_image"]["tmp_name"], $target_file)) {
            // echo "The file ". basename( $_FILES["featured_image"]["name"]). " has been uploaded.";
        } else {
            // echo "Sorry, there was an error uploading your file.";
        }
    }
?>

<html>
    <head>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.0/trix.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
        <script src="http://127.0.0.1:8000/js/jquery..js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.0/trix.js"></script>
    </head>
    <body>
        <div class="form-group">
            <a href="./upload.php" class="btn btn-secondary">Back</a>
        </div>
        <div id="mydiv" style="">
            <div class="img-block">
                <div class="categories-head">
                    <span class="categories">#
                    <?php
                        if ($_POST['post_categories']) {
                            echo $_POST['post_categories'];
                        }
                    ?>
                    </span>
                    <div class="arrow arrow-right"></div>
                </div>
                <img class="img-responsive" src="<?php echo './uploads/'.basename($_FILES["featured_image"]["name"]);?>"/>
                <div class="date-block">
                    <?php
                        // if ($_POST['post_datetime']) {
                        //     echo $_POST['post_datetime'];
                        // } else {
                            echo date('d F Y');
                        // }
                    ?>
                </div>
                <div class="copyright">
                    <i class="fa fa-camera"></i>
                    <span>
                        <?php
                            if ($_POST['post_copright']) {
                                echo $_POST['post_copright'];
                            }
                        ?>
                    </span>
                </div>
            </div>
            <!-- <img class="img-responsive" src="https://enviragallery.com/wp-content/uploads/2017/11/best-places-to-sell-photos-online.jpg"/>-->
            <div class="heading">
                <div>
                    <?php
                        if ($_POST['post_title']) {
                            echo $_POST['post_title'];
                        }
                    ?>
                </div>
            </div>
            <div class="text clearfix">
                <div>
                    <?php
                        if (isset($_POST['post_desc'])) {
                            echo $_POST['post_desc'];
                        }
                    ?>
                </div>
                <div id="background">
                ©GKdemy
                </div>
                <div id="footer">
                    <i class="fa fa-facebook-official" aria-hidden="true"></i>
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                    <i class="fa fa-twitter-square" aria-hidden="true"></i>
                    <i class="fa fa-youtube-play" aria-hidden="true"></i> / GKdemy        
                </div>
            </div>
        </div>
        <div id="canvas" style="display:none">
        <p>Canvas:</p>
        </div>

        <div style="width:200px; float:left" id="image">
        <p style="float:left">Image: </p>
        <a class="" download id="download-image">
        </a>
        </div>
        <div style="float:left;margin-top: 120px;" class="return-data">
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>

        <style>
        #mydiv {
            padding: 10px;
            width: 360px;
            height: auto;
            position: relative;
            margin: 0 auto;
            border: 1px solid #dbdbdb;
            margin-bottom: 25px;
        }
        .arrow-right {
            width: 0; 
            height: 0; 
            border-top: 16px solid transparent;
            border-bottom: 16px solid transparent;
            
            border-left: 10px solid rgba(255, 251, 251, 0.5);
        }
        .heading {
            border-bottom: 2px solid red;
            font-size: 28px;
            font-weight: 600;
        }

        .heading >div {
            border-bottom: 1px solid red;
            text-align: center;
        }

        .img-responsive {
            display: block;
            max-width: 100%;
            height: 300px;
        }
        .copyright {
            position: absolute;
            right: 2rem;
            bottom: 1;
            color: rgba(255, 255, 255, 0.5);;;
        }

        .clearfix:before, .clearfix:after {
            content: " ";
            display: table;
        }

        ul {
            padding: 15px;
        }
        .clearfix:after {
        clear: both; }

        .text {
            margin: 5px 0 0 5;
            position: relative;
        }

        #background {
            position: absolute;
            bottom: 5rem;
            z-index: -1;
            overflow: hidden;
            transform: rotate(-40deg);
            color: #eaeaea;
            font-size: 70px;
        }
        .categories-head {
            position: absolute;
            top: 0;
            display: flex;
        }
        .categories {
            background: rgba(255, 251, 251, 0.5);
            padding: 4px;
        }
        .img-block {
            position: relative;
        }
        .date-block {
            position: absolute;
            top: 0;
            right: 0;
            background: rgba(239, 230, 230, 0.27);
            color: white;
            padding: 2px 5px;
        }
        #footer {
            text-align: center;
            font-size: 20px;
        }
        .fa-facebook-official {
            color: #3b5998;
        }
        .fa-instagram {
            color: #D64B7A;
        }
        .fa-twitter-square {
            color: #00acee;
        }
        .fa-youtube-play {
            color: #c4302b;
        }

        </style>


        <script language="javascript">
            html2canvas([document.getElementById('mydiv')], {
            onrendered: function (canvas) {
            document.getElementById('canvas').appendChild(canvas);
            var data = canvas.toDataURL('image/png');
            //display 64bit imag
            var image = new Image();
            image.src = data;
            document.getElementById('download-image').attributes.href = data;
            console.log(document.getElementById('download-image').setAttribute('href', data));
            // document.getElementById('download-image').attributes('href', data);
            document.getElementById('download-image').appendChild(image);
            // AJAX call to send `data` to a PHP file that creates an PNG image from the dataURI string and saves it to a directory on the server

            var file= dataURLtoBlob(data);

        // Create new form data
        var fd = new FormData();
        fd.append("imageNameHere", file);

        $.ajax({
        url: "upload.php",
        type: "POST",
        data: fd,
        processData: false,
        contentType: false,
        }).done(function(respond){

            // $(".return-data").html("Uploaded Canvas image link: <a href="+respond+">"+respond+"</a>").hide().fadeIn("fast");
            });

        }
        });

        function dataURLtoBlob(dataURL) {
        // Decode the dataURL    
        var binary = atob(dataURL.split(',')[1]);
        // Create 8-bit unsigned array
        var array = [];
        for(var i = 0; i < binary.length; i++) {
            array.push(binary.charCodeAt(i));
        }
        // Return our Blob object
        return new Blob([new Uint8Array(array)], {type: 'image/png'});
        }

        </script>
    </body>
</html>